function next() {
window.location="3.html";
}
function nextt() {
window.location="2.html";
}
function nexttt() {
window.location="3.html";
}
function nextttt() {
	window.location="1.html";
}